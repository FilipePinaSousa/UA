package aula08;

public interface ComidaVegetariana {
    public boolean isVegetarian();
}
