package aula06;

public class contactos{
    private String ID;
    private Pessoa nome;
    private int numero;
    private String email;


    public contactos(String ID,Pessoa nome, int numero,String email){
        this.ID = ID;
        this.nome = nome;
        this.numero = numero;
        this.email = email;
    }

    public Pessoa getNome(){
        return nome;
    }
    public void setNome(Pessoa nome){
        this.nome = nome;
    }


    public int getNumero(){
        return numero;
    }

    public void setNumero(int numero){
        this.numero = numero;
    }

    public String getemail(){
        return email;
    }
    public void setemail(String email){
        this.email = email;
    }
    public String getID(){
        return ID;
    }
    public String getNumeroFormatado() {
        if (this.numero == 0) {
            return "Sem número";
        } else {
            // Formata o número como uma string com o formato "(XX) XXXX-XXXX"
            String numeroFormatado = String.format("(%02d) %04d-%04d",
                this.numero / 100000000, (this.numero / 10000) % 10000, this.numero % 10000);
            return numeroFormatado;
        }
    }


    public void alterarContacto(int novoNumero,String novoemail, String novoID, Pessoa novonome) {
        this.numero = novoNumero;
        this.email = novoemail;
        this.ID = novoID;
        this.nome = novonome;
        }

    public void removenumeros(int numero, String email, String ID, Pessoa nome){
        this.numero = null;
        this.email = null;
        this.ID = null;
        this.nome = null;

        
    }

    

    public String searchnumero(){
        if (this.numero == 0){
            return "Não tem numero";
        }
        else{
            return this.numero;
        }
    }
 


    public String toString() {
        return "ID: " + ID + ", Nome: " + Pessoa.getName() + ", Número: " + getNumeroFormatado() + ", E-mail: " + email;
    }


}