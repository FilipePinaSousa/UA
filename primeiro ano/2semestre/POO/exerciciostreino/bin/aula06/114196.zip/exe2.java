package aula06;

import java.util.ArrayList;
import java.util.Scanner;

public class exe2 {

    public static void main(String[] args) {
        ArrayList<contactos> listaContactos = new ArrayList<>();
        Scanner inputScanner = new Scanner(System.in);

        int opcao = -1;
        while (opcao != 0) {
            System.out.println("MENU");
            System.out.println("1. Inserir contato");
            System.out.println("2. Alterar contato");
            System.out.println("3. Apagar contato");
            System.out.println("4. Procurar contato");
            System.out.println("5. Listar contatos");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            opcao = inputScanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o nome do contato:");
                    String nomeContato = inputScanner.next();
                    listaContactos.add(new contactos(nomeContato, null, opcao, nomeContato));
                    System.out.println("Contato inserido com sucesso!");
                    break;

                case 2:
                    System.out.println("Digite o nome do contato que deseja alterar:");
                    String nomeContatoAntigo = inputScanner.next();
                    System.out.println("Digite o novo nome do contato:");
                    contactos nomeContatoNovo = inputScanner.next();
                    int index = listaContactos.indexOf(nomeContatoAntigo);
                    if (index != -1) {
                        listaContactos.set(index, nomeContatoNovo);
                        System.out.println("Contato alterado com sucesso!");
                    } else {
                        System.out.println("Contato não encontrado!");
                    }
                    break;

                case 3:
                    System.out.println("Digite o nome do contato que deseja apagar:");
                    String nomeContatoApagar = inputScanner.next();
                    boolean removido = listaContactos.remove(nomeContatoApagar);
                    if (removido) {
                        System.out.println("Contato removido com sucesso!");
                    } else {
                        System.out.println("Contato não encontrado!");
                    }
                    break;

                case 4:
                    System.out.println("Digite o nome do contato que deseja procurar:");
                    String nomeContatoProcurar = inputScanner.next();
                    int indexContato = listaContactos.indexOf(nomeContatoProcurar);
                    if (indexContato != -1) {
                        System.out.println("Contato encontrado!");
                    } else {
                        System.out.println("Contato não encontrado!");
                    }
                    break;

                case 5:
                    System.out.println("Lista de contatos:");
                    for (contactos contato : listaContactos) {
                        System.out.println(contato);
                    }
                    break;

                case 0:
                    System.out.println("Saindo do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }
        }

        
    }

    private static void adicionarContacto(contactos[] contactos) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("ID: ");
        String id = scanner.next();
        System.out.print("Nome: ");
        String nome = scanner.next();
        System.out.print("Número: ");
        int numero = scanner.nextInt();
        System.out.print("E-mail: ");
        String email = scanner.next();
    
        Pessoa pessoa = new Pessoa(nome);
        contactos novoContacto = new contactos(id, pessoa, numero, email);
    
        for (int i = 0; i < contactos.length; i++) {
            if (contactos[i] == null) {
                contactos[i] = novoContacto;
                System.out.println("Contacto adicionado com sucesso!");
                return;
            }
        }
    
        System.out.println("Não é possível adicionar mais contactos.");
    }
    
    private static void removerContacto(contactos[] contactos) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome do contato que deseja apagar:");
        String nomeContatoApagar = scanner.next();
        boolean removido = false;
        for (int i = 0; i < contactos.length; i++) {
            if (contactos[i] != null && contactos[i].getNome().equals(nomeContatoApagar)) {
                contactos[i] = null;
                removido = true;
                System.out.println("Contato removido com sucesso!");
            }
        }
        if (!removido) {
            System.out.println("Contato não encontrado!");
        }
    }
    
    private static void alterarContacto(contactos[] contactos) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do contato que deseja alterar:");
        String nomeContatoAntigo = scanner.next();
        System.out.println("Digite o novo nome do contato:");
        String nomeContatoNovo = scanner.next();
        boolean alterado = false;
        for (int i = 0; i < contactos.length; i++) {
            if (contactos[i] != null && contactos[i].getNome().equals(nomeContatoAntigo)) {
                contactos[i].setNome(nomeContatoNovo);
                alterado = true;
                System.out.println("Contato alterado com sucesso!");
            }
        }
        if (!alterado) {
            System.out.println("Contato não encontrado!");
        }
    }
    
    private static void pesquisarContacto(contactos[] contactos) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do contato que deseja procurar:");
        String nomeContatoProcurar = scanner.next();
        boolean encontrado = false;
        for (int i = 0; i < contactos.length; i++) {
            if (contactos[i] != null && contactos[i].getNome().equals(nomeContatoProcurar)) {
                encontrado = true;
                System.out.println("Contato encontrado! ID: " + contactos[i].getID() + ", Número: " + contactos[i].getNumero() + ", E-mail: " + contactos[i].getemail());
            }
        }
        if (!encontrado) {
            System.out.println("Contato não encontrado!");
        }
    }
    

    private static void listarContactos(contactos[] contactos) {
        System.out.println("Lista de contatos:");
        for (int i = 0; i < contactos.length; i++) {
        if (contactos[i] != null) {
        System.out.println(contactos[i].toString());
        }
    }
    }
    scanner.close();
    }





